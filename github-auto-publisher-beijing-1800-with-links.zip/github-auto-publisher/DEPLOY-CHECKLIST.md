# 多账号部署检查清单

对每个 GitHub 账号重复以下步骤：

- [ ] 登录目标 GitHub 账号
- [ ] 创建新仓库
- [ ] 上传压缩包内全部文件
- [ ] 确认 `.github/workflows/auto-publish.yml` 路径正确
- [ ] 更新 `domains.txt`
- [ ] 开启 `Read and write permissions`
- [ ] 打开 Actions 页面
- [ ] 手动运行 `Daily auto publisher`
- [ ] 确认工作流为绿色成功状态
- [ ] 确认 `posts` 下生成20篇页面
- [ ] 确认 README 自动出现文章目录

## 每日配置

- 发布时间：北京时间 18:00
- GitHub cron：`0 10 * * *`
- 每天篇数：20
- 每篇域名数：6
- [ ] 确认根目录生成 `latest-links.txt`
- [ ] 确认 `daily-links` 下生成当天 `.txt` 和 `.md` 汇总
- [ ] 打开 `latest-links.txt` 的 Raw 页面测试整段复制
