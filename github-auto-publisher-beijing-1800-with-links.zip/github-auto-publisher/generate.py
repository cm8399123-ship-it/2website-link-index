from __future__ import annotations

import hashlib
import os
import random
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
DOMAIN_FILE = ROOT / "domains.txt"
OUTPUT_DIR = ROOT / "posts"
INDEX_FILE = ROOT / "README.md"
LINKS_DIR = ROOT / "daily-links"
LATEST_LINKS_FILE = ROOT / "latest-links.txt"
TIMEZONE = ZoneInfo("Asia/Shanghai")

POSTS_PER_DAY = int(os.getenv("POSTS_PER_DAY", "20"))
DOMAINS_PER_POST = int(os.getenv("DOMAINS_PER_POST", "6"))

TITLES = [
    "公开网站入口整理",
    "第三方链接维护记录",
    "网站访问核验清单",
    "域名资源分批归档",
    "公开链接更新日志",
    "网站巡检任务记录",
    "第三方站点导航目录",
    "网站链接整理档案",
    "域名入口检查计划",
    "公开网站索引记录",
    "链接维护工作清单",
    "网站地址分组目录",
    "第三方链接归档记录",
    "站点入口复核任务",
    "网站资源维护日志",
    "域名结构分类目录",
    "公开链接巡检工作台",
    "网站入口版本记录",
    "链接状态观察清单",
    "第三方站点收录档案",
]

INTRODUCTIONS = [
    "本页用于整理一批第三方网站入口，方便后续访问、核验和维护。",
    "以下链接仅作为网站地址索引，不代表推荐、合作或内容来源关系。",
    "本页记录待复核的网站地址，实际状态应以人工访问结果为准。",
    "以下内容属于第三方链接归档，不对网站内容和安全性作保证。",
    "本页面用于分批维护公开网站入口，不构成任何形式的认证或背书。",
]

DISCLAIMERS = [
    "第三方网站内容可能随时变化，请访问者自行判断。",
    "未经实际核验，不应将这些网站描述为官方、权威或安全站点。",
    "遇到异常跳转、自动下载或信息提交要求时，请谨慎操作。",
    "网站被收录仅表示地址已进入整理列表，不代表内容得到认可。",
]


def load_domains() -> list[str]:
    if not DOMAIN_FILE.exists():
        raise FileNotFoundError("找不到 domains.txt")

    result: list[str] = []
    for raw in DOMAIN_FILE.read_text(encoding="utf-8").splitlines():
        value = raw.strip()
        if not value or value.startswith("#"):
            continue
        value = value.removeprefix("https://").removeprefix("http://").rstrip("/")
        result.append(value)

    domains = list(dict.fromkeys(result))
    if not domains:
        raise ValueError("domains.txt 中没有有效域名")
    return domains


def seed_for(*parts: object) -> int:
    source = "|".join(str(part) for part in parts)
    digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    return int(digest[:16], 16)


def allocate_domains(domains: list[str], date_text: str) -> list[list[str]]:
    """均衡分配。域名不足时允许轮换复用，但避免同篇重复。"""
    rng = random.Random(seed_for(date_text, "allocation"))
    pool = domains.copy()
    rng.shuffle(pool)

    total_needed = POSTS_PER_DAY * DOMAINS_PER_POST
    expanded: list[str] = []
    cycle = 0
    while len(expanded) < total_needed:
        current = pool.copy()
        random.Random(seed_for(date_text, "cycle", cycle)).shuffle(current)
        expanded.extend(current)
        cycle += 1

    batches: list[list[str]] = []
    cursor = 0
    for post_no in range(1, POSTS_PER_DAY + 1):
        batch: list[str] = []
        while len(batch) < DOMAINS_PER_POST:
            candidate = expanded[cursor]
            cursor += 1
            if candidate not in batch:
                batch.append(candidate)
        random.Random(seed_for(date_text, post_no, "batch")).shuffle(batch)
        batches.append(batch)
    return batches


def numbered(domains: list[str]) -> str:
    return "## 网站入口\n\n" + "\n".join(
        f"{i}. [{d}](https://{d})" for i, d in enumerate(domains, 1)
    )


def checklist(domains: list[str]) -> str:
    return "## 待核验网站\n\n" + "\n".join(
        f"- [ ] [{d}](https://{d})" for d in domains
    )


def table(domains: list[str]) -> str:
    lines = [
        "## 网站检查表",
        "",
        "| 序号 | 网站 | 当前状态 |",
        "|---:|---|---|",
    ]
    lines.extend(
        f"| {i} | [{d}](https://{d}) | 待核验 |"
        for i, d in enumerate(domains, 1)
    )
    return "\n".join(lines)


def suffix_group(domains: list[str]) -> str:
    groups: dict[str, list[str]] = defaultdict(list)
    for domain in domains:
        groups["." + domain.rsplit(".", 1)[-1]].append(domain)
    lines = ["## 按域名后缀分类", ""]
    for suffix in sorted(groups):
        lines.extend([f"### `{suffix}`", ""])
        lines.extend(f"- [{d}](https://{d})" for d in groups[suffix])
        lines.append("")
    return "\n".join(lines).rstrip()


def details(domains: list[str]) -> str:
    midpoint = max(1, len(domains) // 2)
    groups = [domains[:midpoint], domains[midpoint:]]
    lines = ["## 折叠式网站目录", ""]
    for i, group in enumerate(groups, 1):
        if not group:
            continue
        lines.extend(["<details>", f"<summary>第 {i} 组</summary>", ""])
        lines.extend(f"- [{d}](https://{d})" for d in group)
        lines.extend(["", "</details>", ""])
    return "\n".join(lines).rstrip()


def cards(domains: list[str]) -> str:
    lines = ["## 域名记录卡", ""]
    for domain in domains:
        suffix = "." + domain.rsplit(".", 1)[-1]
        lines.extend([
            f"### {domain}",
            "",
            f"- 访问地址：[{domain}](https://{domain})",
            f"- 域名后缀：`{suffix}`",
            "- 当前状态：待核验",
            "- 检查日期：待填写",
            "",
            "---",
            "",
        ])
    return "\n".join(lines).rstrip()


TEMPLATES = [numbered, checklist, table, suffix_group, details, cards]



def build_post_url(filename: str) -> str:
    server = os.getenv("GITHUB_SERVER_URL", "https://github.com").rstrip("/")
    repository = os.getenv("GITHUB_REPOSITORY", "YOUR_ACCOUNT/YOUR_REPOSITORY").strip("/")
    branch = os.getenv("GITHUB_REF_NAME", "main")
    return f"{server}/{repository}/blob/{branch}/posts/{filename}"


def write_daily_links(date_text: str, generated_filenames: list[str]) -> None:
    """生成每天的可复制链接清单，并更新最新链接文件。"""
    if not generated_filenames:
        return

    LINKS_DIR.mkdir(parents=True, exist_ok=True)
    urls = [build_post_url(name) for name in generated_filenames]
    text = "\n".join(urls) + "\n"

    daily_txt = LINKS_DIR / f"{date_text}.txt"
    daily_md = LINKS_DIR / f"{date_text}.md"
    daily_txt.write_text(text, encoding="utf-8")
    LATEST_LINKS_FILE.write_text(text, encoding="utf-8")

    markdown_lines = [
        f"# {date_text} 发布链接汇总",
        "",
        "> 下方链接由工作流自动收集，可整段复制。",
        "",
        "## 纯文本链接",
        "",
        "```text",
        *urls,
        "```",
        "",
        "## 可点击列表",
        "",
    ]
    markdown_lines.extend(
        f"{index}. [{url}]({url})" for index, url in enumerate(urls, 1)
    )
    markdown_lines.append("")
    daily_md.write_text("\n".join(markdown_lines), encoding="utf-8")
    print(f"已生成链接清单：{daily_txt}")
    print(f"已生成链接汇总：{daily_md}")
    print(f"已更新最新链接：{LATEST_LINKS_FILE}")

def update_index(new_entries: list[str]) -> None:
    start_marker = "<!-- AUTO-POSTS-START -->"
    end_marker = "<!-- AUTO-POSTS-END -->"

    if INDEX_FILE.exists():
        current = INDEX_FILE.read_text(encoding="utf-8")
    else:
        current = "# 网站链接整理记录\n"

    if start_marker not in current or end_marker not in current:
        current = current.rstrip() + f"\n\n{start_marker}\n{end_marker}\n"

    before, remainder = current.split(start_marker, 1)
    existing_section, after = remainder.split(end_marker, 1)
    entries = [line for line in existing_section.strip().splitlines() if line.strip()]

    for entry in reversed(new_entries):
        if entry not in entries:
            entries.insert(0, entry)

    updated = (
        before.rstrip()
        + f"\n\n{start_marker}\n"
        + "\n".join(entries)
        + f"\n{end_marker}"
        + after
    )
    INDEX_FILE.write_text(updated, encoding="utf-8")


def build_post(date_text: str, post_no: int, domains: list[str]) -> tuple[str, str] | None:
    seed = seed_for(date_text, post_no)
    title = TITLES[(post_no - 1) % len(TITLES)]
    intro = INTRODUCTIONS[seed % len(INTRODUCTIONS)]
    disclaimer = DISCLAIMERS[(seed // 7) % len(DISCLAIMERS)]
    template = TEMPLATES[(post_no - 1) % len(TEMPLATES)]

    code = f"{post_no:02d}"
    filename = f"{date_text}-{code}.md"
    output = OUTPUT_DIR / filename
    if output.exists():
        print(f"跳过已存在文件：{filename}")
        return None

    content = f"""# {title}：{date_text} 第 {post_no} 篇

> {intro}  
> {disclaimer}

- 发布日期：{date_text}
- 当日编号：{code}
- 本批数量：{len(domains)}
- 页面状态：待复核
- 生成方式：GitHub Actions 自动生成

{template(domains)}

## 维护说明

- 所列链接仅用于导航、检查和归档。
- 未完成实际检查前，应保留“待核验”状态。
- 不应把无关网站标注为新闻来源或合作网站。
- 网站状态可能随时间发生变化。

## 免责声明

本页面不构成推荐、认证、内容背书或安全保证。
"""
    output.write_text(content, encoding="utf-8")
    entry = f"- [{date_text} 第 {post_no} 篇 · {title}](posts/{filename})"
    print(f"已生成：{output}")
    return filename, entry


def main() -> None:
    if POSTS_PER_DAY < 1 or DOMAINS_PER_POST < 1:
        raise ValueError("POSTS_PER_DAY 和 DOMAINS_PER_POST 必须大于 0")

    date_text = datetime.now(TIMEZONE).strftime("%Y-%m-%d")
    domains = load_domains()
    batches = allocate_domains(domains, date_text)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    entries: list[str] = []
    generated_filenames: list[str] = []
    for post_no, batch in enumerate(batches, 1):
        result = build_post(date_text, post_no, batch)
        if result:
            generated_filenames.append(result[0])
            entries.append(result[1])

    if entries:
        update_index(entries)
        write_daily_links(date_text, generated_filenames)
    print(f"完成：本次新增 {len(entries)} 篇。")


if __name__ == "__main__":
    main()
