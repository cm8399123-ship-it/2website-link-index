# GitHub 自动发布模板

本仓库模板会在**北京时间每天 18:00**自动运行，并生成 **20 篇 Markdown 页面**。

> 所生成页面仅用于第三方链接整理、核验和归档，不代表推荐、认证、合作或内容来源关系。

## 自动文章目录

<!-- AUTO-POSTS-START -->
<!-- AUTO-POSTS-END -->

## 快速部署

1. 新建一个 GitHub 仓库，建议先勾选 `Add a README file`。
2. 将压缩包内所有文件上传到仓库根目录，必须保留 `.github/workflows/auto-publish.yml` 的目录结构。
3. 编辑 `domains.txt`，每行填写一个域名，不要写标题或其他说明。
4. 进入仓库：`Settings → Actions → General → Workflow permissions`。
5. 选择 `Read and write permissions`，然后保存。
6. 进入 `Actions → Daily auto publisher → Run workflow`，手动测试一次。
7. 工作流成功后，仓库会出现 `posts/YYYY-MM-DD-01.md` 至 `posts/YYYY-MM-DD-20.md`。

## 默认参数

工作流文件中：

```yaml
env:
  POSTS_PER_DAY: "20"
  DOMAINS_PER_POST: "6"
```

- `POSTS_PER_DAY`：每天生成的页面数量。
- `DOMAINS_PER_POST`：每篇页面放置的域名数量。

域名数量不足时，脚本会在不同文章中均衡轮换复用，但不会在同一篇中重复同一个域名。域名越多，页面之间的重复越少。

## 发布时间

```yaml
- cron: "0 10 * * *"
```

GitHub Actions 的定时表达式按 UTC 计算。UTC 10:00 对应北京时间 18:00。

## 文件说明

```text
.github/workflows/auto-publish.yml  自动工作流
generate.py                        页面生成脚本
domains.txt                        域名列表
README.md                          总目录
posts/                             自动生成页面目录
```

## 多账号部署建议

每个 GitHub 账号都需要分别执行以下操作：

- 新建仓库并上传本模板。
- 在该仓库中开启 Actions 写入权限。
- 手动运行一次工作流验证。
- 按账号需要修改 `domains.txt`。

不需要创建 Personal Access Token，模板默认使用仓库自带的 `GITHUB_TOKEN`。

## 常见问题

### 工作流显示 Permission denied

确认仓库已设置：

```text
Settings → Actions → General → Workflow permissions
→ Read and write permissions
```

### 没有 Run workflow 按钮

确认工作流文件在默认分支，并且包含：

```yaml
workflow_dispatch:
```

### 当天再次运行没有新文件

这是正常的。相同日期和编号的文件已经存在时，脚本会跳过，防止重复提交。

### 想重新生成当天内容

先删除当天 `posts/YYYY-MM-DD-*.md` 文件及 README 中对应条目，再手动运行工作流。

### 想降低页面重复度

增加 `domains.txt` 中的域名数量，或降低 `DOMAINS_PER_POST`。例如每天20篇、每篇6个域名，需要120次域名展示；若只有60个域名，平均每个域名每天会出现约2次。

## 每日发布链接汇总

工作流每次成功生成文章后，还会自动创建以下文件：

```text
daily-links/YYYY-MM-DD.txt   当天20篇文章的纯文本链接，每行一个
daily-links/YYYY-MM-DD.md    当天链接汇总页，包含可复制文本和可点击列表
latest-links.txt             最近一次发布的全部链接，方便直接打开并复制
```

最方便的使用方式：

1. 打开仓库根目录的 `latest-links.txt`。
2. 点击右上方的 `Raw`。
3. 使用 `Ctrl+A` 和 `Ctrl+C` 一次复制全部链接。

链接会按照以下格式自动生成：

```text
https://github.com/账号名/仓库名/blob/main/posts/YYYY-MM-DD-01.md
https://github.com/账号名/仓库名/blob/main/posts/YYYY-MM-DD-02.md
```

脚本会自动读取当前 GitHub 账号、仓库名称和默认运行分支，不需要手工填写仓库地址。
